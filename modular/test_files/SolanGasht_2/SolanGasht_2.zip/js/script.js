$('.owl_special_tours').owlCarousel({
    nav:true,
    dots:true,
    rtl:true,
    loop:true,
    margin:20,
    navText: ["<i class='fas fa-chevron-right'></i>","<i class='fas fa-chevron-left'></i>"],
    autoplay: true,
    autoplayTimeout: 5000,
    autoplaySpeed:3000,
    responsive:{
        0:{
            items:1,
            nav:false,
        },
        600:{
            items:2,
            nav:false,
        },
        1000:{
            items:3
        }
    }
});
$(document).ready(function(){


    $(".chat_button > button").click(() => {
        $('.chat_button > div').toggleClass('active')
        $('.chat_button > div').toggleClass('unactive')
        $('.chat_button > button').toggleClass('active')
        $('.chat_button > button').toggleClass('unactive')

    })



    $(window).scroll(function () {

        let sctop = $(this).scrollTop();

        if(sctop > 20){
            $('#header').addClass('fixedmenu');
        }
        else{

            $('#header').removeClass('fixedmenu');

        }
    });
});



jQuery(document).ready(function($){
    let slider = $('.owl_tour_local');
    slider.each(function () {
        $(this).owlCarousel({
            rtl:true,
            nav: false,
            loop:true,
            dots: true,
            pagination: false,
            margin: 15,
            autoHeight: false,
            stagePadding: 100,
            responsive:{
                0:{
                    items: 1,
                    stagePadding: 25

                },
                767:{
                    items: 2,
                    stagePadding: 50
                },
                1000:{
                    items: 3
                }
            }
        });
    });
});
jQuery(document).ready(function($){
    let slider = $('.owl_tour_Foreign');
    slider.each(function () {
        $(this).owlCarousel({
            rtl:true,
            nav: false,
            loop:true,
            dots: true,
            pagination: false,
            margin: 15,
            autoHeight: false,
            stagePadding: 100,
            responsive:{
                0:{
                    items: 1,
                    stagePadding: 25

                },
                767:{
                    items: 2,
                    stagePadding: 50
                },
                1000:{
                    items: 3
                }
            }
        });
    });
});
jQuery(document).ready(function($){
    let slider = $('.owl_Blog');
    slider.each(function () {
        $(this).owlCarousel({
            rtl:true,
            nav: false,
            loop:true,
            dots: true,
            pagination: false,
            margin: 20,
            autoHeight: false,
            stagePadding: 100,
            responsive:{
                0:{
                    items: 1,
                    stagePadding: 25

                },
                767:{
                    items: 2,
                    stagePadding: 50

                },
                1000:{
                    items: 3
                }
            }
        });
    });
});



// hide #back-top first
$("#scroll-top").hide();
// fade in #back-top
$(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('#scroll-top').fadeIn();
        } else {
            $('#scroll-top').fadeOut();
        }
    });
    // scroll body to 0px on click
    $('#scroll-top').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 1000);
    });


    // scroll body to 0px on click
    $('#scroll-down').click(function () {
        $('body,html').animate({
            scrollTop: document.documentElement.clientHeight - 100
        }, 1000);
    });
});
$(document).ready(function () {
    $(".select2 , .select-route-bus-js , .default-select2 , .gasht-type-js , .select-route-bus-js , .select2_in").select2();
    $('.switch-input-js').on('change', function() {
        if (this.checked && this.value === '1') {
            $('.international-flight-js').css('display', 'flex')
            $('.internal-flight-js').hide()
            $('.flight-multi-way-js').hide()
            $(this).attr('select_type','yes')
        } else {
            $('.internal-flight-js').css('display', 'flex')
            $('.international-flight-js').hide()
            $('.flight-multi-way-js').hide()
            $('.switch-input-js').removeAttr('select_type')
        }
    })
    $('.select-type-way-js').on('click', function () {
        let type = $(this).data('type');
        let class_element = $(`.${type}-one-way-js`);
        let arrival_date =  $(`.${type}-arrival-date-js`)
        if (class_element.is(':checked')) {
            arrival_date.attr("disabled", "disabled");
        } else {
            arrival_date.removeAttr("disabled");
        }
    });
    $('.click_flight_multi_way').on('click', function() {
        $('.flight-multi-way-js').css('display', 'flex')
        $('.internal-flight-js').hide()
        $('.international-flight-js').hide()
    })
    $('.click_flight_oneWay').on('click', function() {
        $('.international-flight-js').css('display', 'flex')
        $('.internal-flight-js').hide()
        $('.flight-multi-way-js').hide()
    })
    $('.click_flight_twoWay').on('click', function() {
        $('.international-flight-js').css('display', 'flex')
        $('.internal-flight-js').hide()
        $('.flight-multi-way-js').hide()
    })
    $(".switch-input-hotel-js").on("change", function () {
        $(".init-shamsi-datepicker").val("")
        $(".init-shamsi-return-datepicker").val("")
        $(".nights-hotel-js").val("")
        if (this.checked && this.value === "1") {
            $(".internal-hotel-js").css("display", "flex")
            $(".international-hotel-js").hide()
            $(".type-section-js").val("internal")
        } else {
            $(".internal-hotel-js").hide()
            $(".international-hotel-js").css("display", "flex")
            $(".type-section-js").val("international")
        }
    })

});