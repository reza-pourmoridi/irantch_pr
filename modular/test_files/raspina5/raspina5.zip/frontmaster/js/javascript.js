
/*******************menu hamberger***********************/
$("#nimbar").click(function(){
    $(".nimitemhamb").slideToggle();
});
function myFunction2(x) {
    x.classList.toggle("change");
}



